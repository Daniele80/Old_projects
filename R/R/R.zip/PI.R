install.packages("readr", repos=c("http://rstudio.org/_packages",   "http://cran.rstudio.com"));
install.packages("compareDF", repos=c("http://rstudio.org/_packages",   "http://cran.rstudio.com"));

library(readr);
library(compareDF);
PI3 <- read_csv("C:/Users/daniele.rocco/OneDrive - Accenture/R/R/PI7.csv");

a       <- subset(PI3, state == 'Analysis');
a_acn   <- subset(PI3, state == 'Analysis'& u_analyst == 'cirillivito');
a_ing   <- subset(PI3, state == 'Analysis'& u_analyst != 'cirillivito');
o       <- subset(PI3, state == 'Open');
o_acn   <- subset(PI3, state == 'Open'&& u_analyst == 'cirillivito');
nd      <- subset(PI3, state == 'Next Development');
rfu     <- subset(PI3, state == 'Ready for UAT');
rfu_nord <- subset(PI3, state == 'Ready for UAT' & (is.na(u_change_release_date)));
rfp     <- subset(PI3, state == 'Ready for Prod');
o_h     <- subset(PI3, state == 'On Hold');
c        <- subset(PI3, state == 'Closed');

# In analisi
a_n <- nrow(a);
# In analisi ACN
a_acn_n <- nrow(a_acn);
# In analisi ACN
a_ing_n <- nrow(a_ing);
# Aperte
o_n <- nrow(o);
# Aperte
o_acn_n <- nrow(o_acn);
# In Lavorazione
nd_n <- nrow(nd);
# Ready for UAT senza rd
rfu_n <- nrow(rfu);
# Ready for UAT senza rd
rfu_nord_n <- nrow(rfu_nord);
# Chiuse
c_n <- nrow(c);

# Ready for Prod
rfp_n <- nrow(rfp);
# 
o_h_n <- nrow(o_h);

# Lavorate
# Assegnate
# Totale lavorate

PI3_OLD <- read_csv("C:/Users/daniele.rocco/OneDrive - Accenture/R/R/PI6.csv");
#PI3_COMP<- compare_df(PI3, PI3_OLD,names(PI3));

PI3_COMP<- compare_df(PI3, PI3_OLD,c('state','u_change_release_date'));
view_html(PI3_COMP);
PI3_COMP_CH<-PI3_COMP~change_summary;


#
bkl_mutui <- read_csv2("C:/Users/daniele.rocco/OneDrive - Accenture/R/R/bkl_mutui.csv");

date_now <- format(Sys.Date(),"%d/%m/19%y");
date_now;
de<-data.frame(date_now,o_acn_n,a_acn_n,nd_n,'X','X',a_ing_n+o_n,'X',rfu_nord_n,rfp_n,o_h_n);
names(de)<-names(bkl_mutui);
newdf <- rbind(bkl_mutui,de);

write.csv(newdf, file = "C:/Users/daniele.rocco/OneDrive - Accenture/R/R/Output_test.csv",row.names=FALSE);
OUT_DF <- read_csv("C:/Users/daniele.rocco/OneDrive - Accenture/R/R/Output_test.csv");





##