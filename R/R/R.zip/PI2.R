install.packages("readr", repos=c("http://rstudio.org/_packages",   "http://cran.rstudio.com"));
#install.packages("compareDF", repos=c("http://rstudio.org/_packages",   "http://cran.rstudio.com"));

PATH_CSV <-"C:/Users/daniele.rocco/OneDrive - Accenture/myproj/R/R/";
PI_MUTUI_CSV <- "PI_Mutui.csv";
PI_MUTUI_CSV_OLD <- "PI_Mutui_OLD.csv";
BACKLOG_MUTUI_HST <- "bkl_mutui.csv";
OUTPUT <- "Output_test.csv";

library(readr);
library(compareDF);
PI_MUTUI <- read_csv(paste(PATH_CSV,PI_MUTUI_CSV,sep=""));

# estrazione dataframe
a       <- subset(PI_MUTUI, state == 'Analysis');
a_acn   <- subset(PI_MUTUI, state == 'Analysis'& u_analyst == 'cirillivito');
a_ing   <- subset(PI_MUTUI, state == 'Analysis'& u_analyst != 'cirillivito');
o       <- subset(PI_MUTUI, state == 'Open');
o_acn   <- subset(PI_MUTUI, state == 'Open'&& u_analyst == 'cirillivito');
nd      <- subset(PI_MUTUI, state == 'Next Development');
rfu     <- subset(PI_MUTUI, state == 'Ready for UAT');
rfu_nord <- subset(PI_MUTUI, state == 'Ready for UAT' & (is.na(u_change_release_date)));
rfp     <- subset(PI_MUTUI, state == 'Ready for Prod');
o_h     <- subset(PI_MUTUI, state == 'On Hold');
c        <- subset(PI_MUTUI, state == 'Closed');

# contatori
# In analisi
a_n <- nrow(a);
# In analisi ACN
a_acn_n <- nrow(a_acn);
# In analisi ACN
a_ing_n <- nrow(a_ing);
# Aperte
o_n <- nrow(o);
# Aperte
o_acn_n <- nrow(o_acn);
# In Lavorazione
nd_n <- nrow(nd);
# Ready for UAT senza rd
rfu_n <- nrow(rfu);
# Ready for UAT senza rd
rfu_nord_n <- nrow(rfu_nord);
# Chiuse
c_n <- nrow(c);

# Ready for Prod
rfp_n <- nrow(rfp);
# 
o_h_n <- nrow(o_h);

# Lavorate
# Assegnate
# Totale lavorate

# inserire file t-1
PI_MUTUI_OLD <- read_csv(paste(PATH_CSV,PI_MUTUI_CSV_OLD,sep="")); 
PI_MUTUI_COMP<- compare_df(PI_MUTUI, PI_MUTUI_OLD, names(PI_MUTUI));

PI_MUTUI_COMP<- compare_df(PI_MUTUI, PI_MUTUI_OLD,c('state','u_change_release_date'));
view_html(PI_MUTUI_COMP);
PI_MUTUI_COMP_CH<-PI_MUTUI_COMP~change_summary;


#
bkl_mutui <- read_csv2(paste(PATH_CSV,BACKLOG_MUTUI_HST,sep=""));

date_now <- format(Sys.Date(),"%d/%m/19%y");
de<-data.frame(date_now,o_acn_n,a_acn_n,nd_n,'X','X',a_ing_n+o_n,'X',rfu_nord_n,rfp_n,o_h_n);
names(de)<-names(bkl_mutui);
newdf <- rbind(bkl_mutui,de);

write.csv(newdf, file = paste(PATH_CSV,OUTPUT,sep=""),row.names=FALSE);
OUT_DF <- read_csv(paste(PATH_CSV,OUTPUT,sep=""));

##
##